integrantes:
Martin Hermosilla

Para compilar: gcc tablaSimbolos.c anlex_parser.c -o anlex_parser
