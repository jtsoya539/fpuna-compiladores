integrantes:
Martin Hermosilla


Para compilar: gcc tablaSimbolos.c anlex_parser_trad.c -o anlex_parser_trad
